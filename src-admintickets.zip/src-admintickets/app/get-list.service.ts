import { Tickets } from './getlist';
import { Observable } from 'rxjs';
import { Injectable, NgModule } from '@angular/core';
import { HttpClient,HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GetListService {
  
  constructor(private http:HttpClient) {}
  
  getticket():Observable<Tickets[]>{
    const url="http://127.0.0.1:4004/tickets";
    return this.http.get<Tickets[]>(url);
  }
}
  
  
 