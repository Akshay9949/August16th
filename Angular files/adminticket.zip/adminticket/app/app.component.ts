import { GetListService } from './get-list.service';
import { Tickets} from './getlist';

import { Subscription } from 'rxjs';
import { HttpClient, HttpClientModule,HttpErrorResponse } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Component,NgModule,OnInit} from '@angular/core';
import { stringify } from '@angular/compiler/src/util';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'user';
  data:Array<any>;
  result;
  constructor(private http:HttpClient,private getlist:GetListService){
    this.data=Array<any>();
  }
  ticketlist;
  ngOnInit () {
  this.getlist.getticket().subscribe((data=>this.ticketlist=data)) 
}
 updatestatus(ticketId:number,event:MouseEvent){
   const url="http://127.0.0.1:4004/status";
   this.http.put(url,{'ticketId':ticketId}).toPromise().then((data:any)=>{
    console.log(data);  
    (event.target as HTMLButtonElement).disabled = true;
  })
 }
}


