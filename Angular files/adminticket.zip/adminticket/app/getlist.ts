export interface Tickets{
    ticketId:number;
     dateTicketRaised:Date;
    phone:string;
     planCategory:string;
     ticket:string;
     status:boolean;
    
}



